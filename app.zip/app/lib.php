<?php

session_start();

function cekLogin(){
    if(isset($_SESSION['username'])){
        return true;
    } else {
        return false;
    }
}

function login($username, $password){
    $usersaya = 'yudhistira';
    $passsaya = 'uphmedan2023';
    $level = 'admin';

    if(($username == $usersaya) && ($password == $passsaya))
    {
        $_SESSION['username'] = $username;
        $_SESSION['level'] = $level;
        return true;
    } else {
        return false;
    }
}

function isAdmin(){
    if($_SESSION['level'] == 'admin'){
        return true;
    } else {
        return false;
    }
}