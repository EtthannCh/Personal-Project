<?php

require_once "lib.php";

$username = $_POST['username'];
$password = $_POST['password'];

if(login($username,$password)){
    if(isAdmin()){
        header('location: admin-dashboard.php');
    } else {
        header('location: index.php');
    }
 
} else {
    header('location: login.php');
}